// Please do not change the prewritten code

const Solution = async () => {
  // Write your code here
};
Solution();
module.exports = Solution;
