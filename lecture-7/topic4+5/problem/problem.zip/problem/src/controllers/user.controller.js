// Please don't change the pre-written code
// Import the necessary modules here

export default class UserController {
  getRegister = (req, res, next) => {
    // Write your code here
  };
  getLogin = (req, res, next) => {
    // Write your code here
  };
  addUser = (req, res) => {
    // Write your code here
  };
  loginUser = (req, res) => {
    // Write your code here
  };
}
