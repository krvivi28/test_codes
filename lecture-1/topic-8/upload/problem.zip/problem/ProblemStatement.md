Title:
Creating a Node.js HTTP Server

Introduction:
You are tasked with creating a server that listens on port 8080.

Objectives:

1.Create a server using the HTTP module and store the server instance in a variable named "server".
2.Configure the server to listen on port 8080.
3.The server should respond with the message, "Response received at port 8080."

Expected Output:

Requirements:

Use the HTTP module to create the server.
