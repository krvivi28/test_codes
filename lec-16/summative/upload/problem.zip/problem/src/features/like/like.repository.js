// Please don't change the pre-written code
// Import the necessary modules here

export const likeRepo = async (user_id, job_id, model) => {
  // Write your code here
};
export const getLikesRepo = async (id, on_model) => {
  // Write your code here
};
