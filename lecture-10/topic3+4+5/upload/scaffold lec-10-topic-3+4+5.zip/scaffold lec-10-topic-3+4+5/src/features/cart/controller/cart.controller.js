// Please don't change the pre-written code
// Import the necessary modules here

export const addToCartController = (req, res) => {
  // Write your code here
};

export const removeFromCartController = (req, res) => {
  // Write your code here
};
